import './Hero.scss';

const Hero = () => {
  return (
    <section className='hero hero-container'>
      <h2 className='hero__title'>Best nutrition blogs.</h2>
    </section>
  );
};

export default Hero;
