const withCSS = require("@zeit/next-css");

// const withSass = require('@zeit/next-sass');

const withStyles = require('@webdeb/next-styles')

const withPlugins = require('next-compose-plugins');

const withCss=withCSS({
    webpack: function (config) {
      config.module.rules.push({
        test: /\.(eot|woff|woff2|ttf|svg|png|jpg|gif)$/,
        use: {
          loader: 'url-loader',
          options: {
            limit: 100000,
            publicPath: '/_next/static/',
            outputPath: 'static/',
            name: '[name].[ext]'
          }
        }
      })
      return config
    }
 })

 const withSTYLES = withStyles({
  sass: true, // use .scss files
  modules: true, // style.(m|module).css & style.(m|module).scss for module files
})

// const withSass = require('@zeit/next-sass');
// module.exports = withSass({
//   cssModules: true,
//   cssLoaderOptions: {
//     importLoaders: 2,
//   },
//   webpack: config => {
//     config.module.rules.forEach(rule => {
//       if (rule.test.toString().includes('.scss')) {
//         rule.rules = rule.use.map(useRule => {
//           if (typeof useRule === 'string') {
//             return { loader: useRule };
//           }
//           if (useRule.loader === 'css-loader') {
//             return {
//               oneOf: [
//                 {
//                   test: new RegExp('.global.scss$'),
//                   loader: useRule.loader,
//                   options: {},
//                 },
//                 {
//                   loader: useRule.loader,
//                   options: { modules: true }
//                 },
//               ],
//             };
//           }
//           return useRule;
//         });
//         delete rule.use;
//       }
//     });
//     return config;
//   },
// });

const nextConfig = {
  serverRuntimeConfig: {
    // Will only be available on the server side
    PRODUCTION: true,
    API_PRODUCTION: 'https://untappedblogapi.herokuapp.com/',
    API_DEVELOPMENT: 'http://localhost:8080',
    APP_NAME: 'Untapped Nutrition',
    DOMAIN_PRODUCTION: 'https://untappednutrition.co.ke',
    DOMAIN_DEVELOPMENT: 'http://localhost:3000',
    FB_APP_ID: process.env.FB_APP_ID,
    DISQUS_SHORTNAME: 'untahnnhjn',
    GOOGLE_CLIENT_ID: process.env.GOOGLE_CLIENT_ID
  },
  publicRuntimeConfig: {
    // Will be available on both server and client
    //staticFolder: '/static',
    PRODUCTION: true,
    API_PRODUCTION: 'https://untappedblogapi.herokuapp.com/api',
    API_DEVELOPMENT: 'http://localhost:8080',
    APP_NAME: 'Untapped Nutrition',
    DOMAIN_PRODUCTION: 'https://untappednutrition.co.ke',
    DOMAIN_DEVELOPMENT: 'http://localhost:3000',
    FB_APP_ID: process.env.FB_APP_ID,
    DISQUS_SHORTNAME: 'untahnnhjn',
    GOOGLE_CLIENT_ID: process.env.GOOGLE_CLIENT_ID
  },
}

const config = {
  ...nextConfig,
  webpack: webpackConfig => webpackConfig,
}


module.exports = withPlugins([
  [withCss],
  [withSTYLES]
], config);