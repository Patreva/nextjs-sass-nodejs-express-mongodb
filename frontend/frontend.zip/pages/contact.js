import Layout from '../components/Layout';
import ContactForm from '../components/ContactForm/ContactForm';

const Index = () => (
  <Layout>
    <ContactForm />
  </Layout>
);

export default Index;
